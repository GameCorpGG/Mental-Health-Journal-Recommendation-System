package com.Rachit.mental_health;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MhjrsApplication {

    public static void main(String[] args) {
        SpringApplication.run(MhjrsApplication.class, args);
    }
}
