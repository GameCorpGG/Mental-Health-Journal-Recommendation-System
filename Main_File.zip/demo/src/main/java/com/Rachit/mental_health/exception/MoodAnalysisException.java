package com.Rachit.mental_health.exception;

public class MoodAnalysisException extends RuntimeException {
    public MoodAnalysisException(String message) {
        super(message);
    }
}
