package com.Rachit.mental_health;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = com.Rachit.mental_health.MhjrsApplication.class)
class MhjrsApplicationTests {

	@Test
	void contextLoads() {
	}

}
