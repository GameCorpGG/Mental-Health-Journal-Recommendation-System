package com.Rachit.mental_health.service;

import com.Rachit.mental_health.dto.ContentDTO;
import com.Rachit.mental_health.dto.UserDTO;
import com.Rachit.mental_health.entity.Content;
import com.Rachit.mental_health.entity.User;
import com.Rachit.mental_health.exception.ResourceNotFoundException;
import com.Rachit.mental_health.repository.ContentRepository;
import com.Rachit.mental_health.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class AdminServiceImpl implements AdminService {

    private final UserRepository userRepository;
    private final ContentRepository contentRepository;

    @Override
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    @Override
    public void deleteUserById(Long UserId) {
        User user = userRepository.findByUserId(UserId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with ID" + UserId));
        userRepository.delete(user);
    }

    @Override
    public List<Content> getAllContent() {
        return contentRepository.findAll();
    }

    @Override
    public void deleteContentById(Long ContentId) {
        Content content = contentRepository.findByContentId(ContentId)
                .orElseThrow(() -> new ResourceNotFoundException("Content not found with ID" + ContentId));
        contentRepository.delete(content);
    }

    @Override
    public List<UserDTO> findUser(Long userId) {
        return userRepository.findByUserId(userId).stream().map(user -> {
            UserDTO dto = new UserDTO();
            dto.setName(user.getUsername());
            dto.setEmail(user.getEmail());
            dto.setRole(user.getRole());
            return dto;
        }).collect(Collectors.toList());
    }

    @Override
    public Content approveContent(Long ContentId) {
        Content content = contentRepository.findByContentId(ContentId)
                .orElseThrow(() -> new ResourceNotFoundException("Content not found with ID" + ContentId));
        content.setStatus("APPROVED");
        return contentRepository.save(content);
    }

    @Override
    public Content rejectContent(Long ContentId) {
        Content content = contentRepository.findByContentId(ContentId)
                .orElseThrow(() -> new ResourceNotFoundException("Content not found with ID" + ContentId));
        content.setStatus("REJECTED");
        return contentRepository.save(content);
    }
}

