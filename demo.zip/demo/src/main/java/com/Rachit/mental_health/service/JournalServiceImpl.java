package com.Rachit.mental_health.service;

import com.Rachit.mental_health.dto.JournalEntryDTO;
import com.Rachit.mental_health.entity.JournalEntry;
import com.Rachit.mental_health.entity.User;
import com.Rachit.mental_health.repository.JournalRepository;
import com.Rachit.mental_health.repository.UserRepository;
import com.Rachit.mental_health.exception.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class JournalServiceImpl implements JournalService {

    @Autowired
    private JournalRepository journalRepository;

    @Autowired
    private UserRepository userRepository;

    @Override
    public JournalEntryDTO addJournalEntry(Long UserId, JournalEntryDTO dto) {
        User user = userRepository.findByUserId(UserId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with the user ID: " + UserId));

        JournalEntry entry = new JournalEntry();
        entry.setUser(user); // from userRepository.findByEmail(...)
        entry.setTitle(dto.getTitle());
        entry.setContent(dto.getContent());
        entry.setEntryDate(LocalDate.now());

        JournalEntry saved = journalRepository.save(entry);

        JournalEntryDTO response = new JournalEntryDTO();
        response.setEntryId(saved.getJournalId());
        response.setUserId(saved.getUser().getUserId());
        response.setTitle(saved.getTitle());
        response.setContent(saved.getContent());
        response.setEntryDate(saved.getEntryDate());

        return response;
    }

    @Override
    public List<JournalEntryDTO> getEntriesByUserId(Long UserId) {
        User user = userRepository.findByUserId(UserId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        return journalRepository.findByUser(user).stream().map(entry -> {
            JournalEntryDTO dto = new JournalEntryDTO();
            dto.setEntryId(entry.getJournalId());
            dto.setTitle(entry.getTitle());
            dto.setEntryDate(entry.getEntryDate());
            dto.setContent(entry.getContent());
            return dto;
        }).collect(Collectors.toList());
    }
}
